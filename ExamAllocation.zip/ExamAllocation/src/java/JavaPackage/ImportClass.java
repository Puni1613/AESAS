/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaPackage;

import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author punith
 */
public class ImportClass extends HttpServlet {
    HttpServletResponse response;
    public static void Store(String filePath)
    {
    //  PrintWriter pw=response.getWriter();
      Runtime r = Runtime.getRuntime();
       Process p = null;
        String command = "mongoimport --db SEATALLOCATION --collection Contacts --type csv --file filePart --headerline";
  try {
   p = r.exec(command);
 //  pw.println("Reading csv into Database");
    }
  catch (Exception e){
   //pw.println("Error executing " + command + e.toString());
  }
    }
    
}
