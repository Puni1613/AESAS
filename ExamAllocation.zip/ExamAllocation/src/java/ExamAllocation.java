/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.regex.*;

/**
 *
 * @author punith
 */
public class ExamAllocation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        MongoClient mongo=new MongoClient("localhost",27017);
        DB db=mongo.getDB("SEATALLOCATION");
        DBCollection col=db.getCollection("Department");
      Pattern P=Pattern.compile("[:]");
     
       Hashtable<String,String> hs=new Hashtable<String,String>(); 
       LinkedList<String> Final=new LinkedList<String>();
       LinkedList<String> Lecturer=new LinkedList<String>();
        ArrayList<String> Deptt=new ArrayList<String>();

        int form1=Integer.parseInt(request.getParameter("mytextarea"));
        int form2=Integer.parseInt(request.getParameter("mytextarea1"));
        int form3=Integer.parseInt(request.getParameter("mytextarea2"));
       
         pw.println(request.getMethod()+form1+form2+form3);
         String na=request.getParameter("deptnum");
        
        String values[]=request.getParameterValues("deptnum");
        String rooms[]=(request.getParameterValues("roomid"));
        for(int j=0;j<rooms.length;j++)
        {
                pw.print(rooms[j]);
                String str[]=P.split(rooms[j]);
               
               hs.put(str[0],str[1]);
                 
        }
        pw.print(hs.size());
        
        List<String> []list=new LinkedList[values.length];
         List<String> []lect=new LinkedList[values.length];
        for(int i=0;i<values.length;i++)
        {
            list[i]=new LinkedList<String>();
            lect[i]=new  LinkedList<String>();
        }
        
        for(int i=0;i<values.length;i++)
        {
        Deptt.add(values[i].trim());
        BasicDBObject query=new BasicDBObject();
        BasicDBObject fields=new BasicDBObject();
        query.put("Department", values[i].trim());
        fields.put("USN",1);
        fields.put("Lecturers",1);
        DBCursor cur=col.find(query,fields);
       /// pw.print(cur.hasNext());
        while(cur.hasNext())
            {
                DBObject doc=cur.next(); 
                String name=(String)doc.get("USN");
                String Lect=(String)doc.get("Lecturers");
                if(name!=null)
                            list[i].add(name); 
                
                if(Lect!=null)
                      lect[i].add(Lect);
            }
      
       }
        
        DBCollection collect=db.getCollection("Allocations");
        BasicDBObject query=new BasicDBObject();
        if(hs.size()==0)
        {
        }
        else if(hs.size()==1 && (values.length==1))
            {
                
                Object[] crunchifyKeys = hs.keySet().toArray();
		Object key = crunchifyKeys[new Random().nextInt(crunchifyKeys.length)];
            query.append("RoomID",key);
            query.append("Departments",Deptt);
            query.append("Studentds",list[0]);
            query.append("No_of_Students",list[0].size());
            query.append("Lecturers",lect[0]);
            collect.insert(query);
             request.setAttribute("RoomID", key);
             request.setAttribute("Pattern1", form1);
             request.setAttribute("Pattern2", form2);
             request.setAttribute("Pattern3", form3);
             request.getRequestDispatcher("PdfGeneration.jsp").forward(request, response);
            
            }
        else if((hs.size()==1) &&(values.length>1))
           {
           
                                        int sum=0;
                                     for(int i=0;i<values.length;i++)
                                     {
                                     sum+=list[i].size();
                                     for(String a:list[i])
                                     Final.add(a);

                                     for(String b:lect[i])
                                    Lecturer.add(b);
                                     }

                                       Object[] crunchifyKeys = hs.keySet().toArray();
                                       Object key = crunchifyKeys[new Random().nextInt(crunchifyKeys.length)];
                                             pw.println(sum);
                                           
                                     {
                                        
                                         query.append("RoomID",key);
                                         query.append("Departments",Deptt);
                                         query.append("Studentds",Final);
                                         query.append("No_of_Students",Final.size());
                                         query.append("Lecturers",Lecturer);
                                         collect.insert(query); 
                                         request.setAttribute("RoomID", key);
                                         request.setAttribute("Pattern1", form1);
                                         request.setAttribute("Pattern2", form2);
                                         request.setAttribute("Pattern3", form3);

                                          request.getRequestDispatcher("PdfGeneration.jsp").forward(request, response);
                                     }
                                   
        
        }
        else if(hs.size()>1 && (values.length==1))
        {
          int sum_of_Students=0;
          int count=0;
        Object[] crunchifyKeys = hs.keySet().toArray();
         Object key = crunchifyKeys[new Random().nextInt(crunchifyKeys.length)];
		//Object key = crunchifyKeys[new Random().nextInt(crunchifyKeys.length)];
                 for(int i=0;i<hs.size();i++)
                 {
                    key = crunchifyKeys[new Random().nextInt(crunchifyKeys.length)];
                    sum_of_Students+=Integer.parseInt(hs.get(key));
                    if(list[0].size() <  sum_of_Students)
                    {
                        count++;
                    break;
                    }
                 }
                 if(count==1)
                 {
                            query.append("RoomID",key);
                            query.append("Departments",Deptt);
                            query.append("Studentds",list[0]);
                             query.append("No_of_Students",list[0].size());
                            query.append("Lecturers",lect[0]);
                            collect.insert(query); 
                            request.setAttribute("RoomID", key);
                                request.setAttribute("Pattern1", form1);
                                request.setAttribute("Pattern2", form2);
                                request.setAttribute("Pattern3", form3);
                                request.getRequestDispatcher("PdfGeneration.jsp").forward(request, response);
                 }
                 else if(count>1)
                 {
                    
                    
                 
                 }
                 
            
        }
      


        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
