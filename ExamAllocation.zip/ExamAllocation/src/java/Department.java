/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author punith
 */
import java.util.*;
class Department
{
    private boolean isOdd;
    private String Name;
    private int id;
    private int Number_of_Semister;
    private String Lecturers[];
     private ArrayList<String>[] Sem = (ArrayList<String>[]) new ArrayList[Number_of_Semister];
//for(int i = 0; i < anArray.length; i++)
  // anArray[i] = new ArrayList<Integer>();
   public  Department(int id,String Name,int semister,boolean value)
    {
        this.id=id;
        this.Name=Name;
        this.Number_of_Semister=semister;
        this.isOdd=value;
        for(int i=1;i<=Number_of_Semister;i++)
        {
        Sem[i]=new ArrayList<String>();
        }
    }
         public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
     
       public void Addsem_Students(ArrayList<String> sem1,int i)
       {
       this.Sem[i]=sem1;
       }
       public ArrayList<String> getStudents(int i)
       {
       return Sem[i];
       }
       
       public void setLecturer(String[] lecturers)
       {
       this.Lecturers=lecturers;
       }
       public String[] getLecturers()
       {
       return Lecturers;
       }
   
}