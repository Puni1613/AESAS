/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.*;

/**
 *
 * @author punith
 */
public class servlet2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        String user=request.getParameter("user");
        String password=request.getParameter("pass");
        MongoClient mongoo=new MongoClient("localhost",27017);
      // pw.println(user + password);
        DB db=mongoo.getDB("SEATALLOCATION");
        DBCollection dbcc=db.getCollection("Users");
        BasicDBObject query=new BasicDBObject();
        BasicDBObject fields=new BasicDBObject();
        query.put("Name",user);
        query.put("Password",password);
        fields.put("Type",1);
        DBCursor doc = dbcc.find(query,fields);
        if(doc.hasNext())
        {
           DBObject document=doc.next();
            String a=(String)document.get("Type");
            
           pw.println(a);
           
           if(a.equalsIgnoreCase("Admin"))
            {
                request.setAttribute("user", user);
                //response.sendRedirect("AdminMasterPage.html");
                request.getRequestDispatcher("AdminMaster.jsp").forward(request, response);
            }
            else if(a.equalsIgnoreCase("Student"))
            {
                 request.setAttribute("user", user);
               
                request.getRequestDispatcher("StudentsMaster.jsp").forward(request, response);
              // response.sendRedirect("StudentsMaster.html");
            }
            else if(a.equalsIgnoreCase("Lecturers"))
            { request.setAttribute("user", user);
               
                request.getRequestDispatcher("LecturerMaster.jsp").forward(request, response);
                
              // response.sendRedirect("LecturerMaster.html"); 
            }
             else if(a.equalsIgnoreCase("DepartMentTestCo-ordinator"))
            { request.setAttribute("user", user);
               
                request.getRequestDispatcher("TestCoDept.jsp").forward(request, response);
                
              // response.sendRedirect("LecturerMaster.html"); 
            }
           
            
        
        
    }
        else
           
            {
               pw.println("<script type=\"text/javascript\">");
                 pw.println("alert('User or password incorrect');");
                  pw.println("location='start.html';");
                    pw.println("</script>");
           
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
