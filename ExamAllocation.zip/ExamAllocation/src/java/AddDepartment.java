/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.MongoClient;
import com.mongodb.DBCollection;
import com.mongodb.DB;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.*;
import javax.servlet.http.Part;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import com.oreilly.servlet.MultipartRequest;  
import com.opencsv.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FilterReader;

/**
 *
 * @author punith
 */
public class AddDepartment extends HttpServlet {
public final String UP_Directory="/home/punith/NetBeansProjects/ExamAllocation/web/Files";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        PrintWriter pw=response.getWriter();
       
        try{
        MultipartRequest m=new MultipartRequest(request,UP_Directory);//to fetch thea csv file and stored it in the server
       // get the column count
       // out.print("hello");
       Enumeration<String> Filename= m.getFileNames();
       while(Filename.hasMoreElements())
                 {
                   String filename="/home/punith/NetBeansProjects/ExamAllocation/web/Files/"+m.getOriginalFileName(Filename.nextElement());
                   //out.println(filename);
                   Runtime r = Runtime.getRuntime();
                        Process p = null;
                        String command = "mongoimport --db SEATALLOCATION --collection Department --type csv --file "+filename+" --headerline";
                        try {
                                                p = r.exec(command);
                                                //out.println("Reading csv into Database");
                                                
                           }
            catch (Exception e){
                        pw.println("Error executing " + command + e.toString());
                        }                
                 }
       
            
    }
        catch(Exception ex)
        {
            request.setAttribute("message", ex);
        }
      // request.setAttribute("message", "FilesUploaded Sucesfully");
      // request.getRequestDispatcher("AdminMaster.jsp").forward(request, response);
        
         pw.println("<script type=\"text/javascript\">");
                 pw.println("alert('Department file added sucessfully');");
                  pw.println("location='AdminMaster.jsp';");
                    pw.println("</script>");
           
        
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
