/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mongodb.*;
import java.util.ArrayList;

/**
 *
 * @author punith
 */
public class Servlet_Enter extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html");
        PrintWriter pw=response.getWriter();
        ArrayList<Integer> rooms=new ArrayList<Integer>();
        String Department=request.getParameter("name");
        MongoClient mongo=new MongoClient("localhost",27017);
        DB db=mongo.getDB("SEATALLOCATION");
        DBCollection col=db.getCollection("Allocations");
        DBCursor cur=col.find();
        while(cur.hasNext())
        {
            DBObject doc=cur.next();
        java.util.List<String> linked=(java.util.List<String>)doc.get("Departments");
         String[] array1 = linked.toArray(new String[linked.size()]);
         for(int i=0;i<array1.length;i++)
         {
             pw.println(array1[i]);
             if(array1[i].equalsIgnoreCase(Department))
             {
                rooms.add(Integer.parseInt((String)doc.get("RoomID")));
             }
             pw.println(rooms.size());
         }
        }
        if(rooms.size()==0)
        {
           //request.setAttribute("Rooms", col);
            pw.println("Department not allocated");
        }
        else
        {
            for(int a:rooms)
            {
            pw.println("<a href=Pdf/"+a+".pdf"+"/a>"+a+"</a>"+"\n");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
